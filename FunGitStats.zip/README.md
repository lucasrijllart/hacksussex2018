# Github usage statistics for repos

This is the repo for our hack at the HackSussex 2018.

Github repo usage graphs by author over time and number of commits by author.

Also includes statistics on shortest commit message and converting commit messages to haikus.

To run, you will need to link it to another local repo (we used github.com/lucasrijllart/sleep-wake)
